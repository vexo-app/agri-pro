// src/pages/JobsPage.jsx
import React, { useState } from "react";
import { useJobs }      from "../hooks/useJobs";
import { useData }      from "../contexts/DataContext";
import { useAuth }      from "../contexts/AuthContext";
import { createJobWithInitialPayment } from "../utils/jobCreation";
import JobCard          from "../features/jobs/JobCard";
import JobForm          from "../features/jobs/JobForm";
import JobFilters       from "../features/jobs/JobFilters";
import DeleteJobDialog  from "../features/jobs/DeleteJobDialog";
import Modal            from "../components/ui/Modal";
import Button           from "../components/ui/Button";
import { EmptyState }   from "../components/ui/Card";
import LoadingScreen    from "../components/ui/LoadingScreen";
import { PlusIcon, ClipboardIcon, RevenueIcon, FuelIcon, WrenchIcon, ProfitIcon, AcreIcon } from "../components/ui/Icons";
import { formatCurrency, formatNumber } from "../utils/formatters";
import { TEAM_ROLE } from "../config/constants";
import { trackEvent } from "../config/posthog";

const SummaryBadge = ({ Icon, label, value, color }) => (
  <div className="bg-surface border border-white/8 rounded-2xl px-4 py-3 flex-1 min-w-[120px]">
    <div className="flex items-center gap-2 mb-1">
      {Icon && <Icon size={14} className={color} />}
      <p className={`text-sm font-extrabold tabular-nums ${color}`}>{value}</p>
    </div>
    <p className="text-[11px] text-gray-500">{label}</p>
  </div>
);

const JobsPage = () => {
  const { jobs, totals, totalMaintCost, netProfit, filters, setFilters, clearFilters, hasActiveFilters, loading, addJob, updateJob, deleteJob, fuelPrice } = useJobs();
  const { equipment, drivers: allTeamMembers, payments, addPayment, deletePayment } = useData();
  const { user } = useAuth();
  // العمليات الميدانية بتتسند لسائقين بس — الإداريين والمحاسبين مالهمش
  // علاقة بيها، فمش بيظهروا في قوايم الإسناد/الفلترة دي.
  const drivers = allTeamMembers.filter((d) => (d.role || TEAM_ROLE.DRIVER) === TEAM_ROLE.DRIVER);
  const [modal, setModal] = useState(null);
  const [deleteTargetId, setDeleteTargetId] = useState(null); // job id currently pending delete confirmation

  const openAdd    = ()      => setModal({ mode: "add" });
  const openEdit   = (job)   => setModal({ mode: "edit", data: job });
  const closeModal = ()      => setModal(null);

  const handleSave = async (formData) => {
    if (modal.mode === "add") {
      const { hasInitialPayment } = await createJobWithInitialPayment({
        formData, userId: user.uid, addJob, addPayment, deletePayment,
      });
      trackEvent("job_created", { has_initial_payment: hasInitialPayment });
    } else {
      await updateJob(modal.data.id, formData);
      trackEvent("job_updated");
    }
  };

  const handleDelete = (id) => setDeleteTargetId(id);

  // الدفعات (المعلومات المالية) المرتبطة بالعملية المطلوب حذفها — بتتحسب
  // عشان نوريها للمستخدم في نافذة التأكيد قبل ما يدخل الباسورد.
  const targetPayments  = deleteTargetId ? payments.filter((p) => p.jobId === deleteTargetId) : [];
  const targetPaymentsTotal = targetPayments.reduce((s, p) => s + (Number(p.amount) || 0), 0);

  const handleConfirmDelete = async () => {
    await deleteJob(deleteTargetId);
    trackEvent("job_deleted");
  };

  if (loading) return <LoadingScreen />;

  return (
    <div className="p-4 lg:p-6 max-w-7xl mx-auto" dir="rtl">
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-xl font-extrabold text-gray-100 flex items-center gap-2">
            <ClipboardIcon size={22} className="text-brand-400" />
            سجل الشغل
          </h1>
          <p className="text-sm text-gray-500 mt-0.5">{jobs.length} عملية{hasActiveFilters ? " (مفلترة)" : ""}</p>
        </div>
        <Button onClick={openAdd} icon={<PlusIcon size={16} />}>تسجيل عملية</Button>
      </div>

      {jobs.length > 0 && (
        <div className="flex flex-wrap gap-3 mb-5">
          <SummaryBadge Icon={RevenueIcon} label="إجمالي الإيراد"  value={formatCurrency(totals.totalRevenue)}   color="text-amber-400" />
          <SummaryBadge Icon={FuelIcon}    label="تكلفة الوقود"    value={formatCurrency(totals.totalFuelCost)}  color="text-red-400" />
          <SummaryBadge Icon={WrenchIcon}  label="تكلفة الصيانة"   value={formatCurrency(totalMaintCost)}        color="text-red-400" />
          <SummaryBadge Icon={ProfitIcon}  label="صافي الربح"      value={formatCurrency(netProfit)}             color={netProfit >= 0 ? "text-green-400" : "text-red-400"} />
          <SummaryBadge Icon={AcreIcon}    label="إجمالي الأفدنة"  value={`${formatNumber(totals.totalAcres)} فدان`} color="text-blue-400" />
        </div>
      )}

      <div className="mb-5">
        <JobFilters filters={filters} setFilters={setFilters} clearFilters={clearFilters}
          hasActiveFilters={hasActiveFilters} equipment={equipment} drivers={drivers} />
      </div>

      {jobs.length === 0 ? (
        <EmptyState
          icon={<ClipboardIcon size={48} className="text-gray-600 mx-auto mb-2" />}
          title={hasActiveFilters ? "لا توجد نتائج للفلتر الحالي" : "لا توجد عمليات بعد"}
          description={hasActiveFilters ? "جرّب تغيير الفلاتر" : "سجّل أول عملية عمل الآن"}
          action={
            hasActiveFilters
              ? <Button variant="ghost" onClick={clearFilters}>مسح الفلاتر</Button>
              : <Button onClick={openAdd} icon={<PlusIcon size={16} />}>تسجيل أول عملية</Button>
          }
        />
      ) : (
        <div className="space-y-3">
          {jobs.map((job) => {
            const eq  = equipment.find((e) => e.id === job.equipmentId);
            const drv = drivers.find((d)  => d.id === job.driverId);
            return <JobCard key={job.id} job={job} equipmentName={eq?.name} driverName={drv?.name}
              onEdit={() => openEdit(job)} onDelete={() => handleDelete(job.id)} />;
          })}
        </div>
      )}

      <Modal open={!!modal} onClose={closeModal}
        title={modal?.mode === "add" ? "تسجيل عملية جديدة" : "تعديل العملية"} size="lg">
        {modal && <JobForm mode={modal.mode} initial={modal.data} equipment={equipment} drivers={drivers}
          fuelPrice={fuelPrice} onSave={handleSave} onClose={closeModal} />}
      </Modal>

      <DeleteJobDialog
        open={!!deleteTargetId}
        onClose={() => setDeleteTargetId(null)}
        onConfirm={handleConfirmDelete}
        paymentsCount={targetPayments.length}
        paymentsTotal={targetPaymentsTotal}
      />
    </div>
  );
};

export default JobsPage;
