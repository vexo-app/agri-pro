// src/hooks/useDrivers.js
import { useMemo, useCallback } from "react";
import { useData } from "../contexts/DataContext";
import { buildDriverReport } from "../utils/calculations";
import { getMonthEntries } from "../utils/salaryCalculations";
import { SALARY_ENTRY_TYPES, DRIVER_STATUS } from "../config/constants";

const getCurrentMonth = () => {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
};

export const useDrivers = () => {
  const {
    drivers, jobs, payments, settings,
    salaryEntries = [], attendance = [], equipment = [], custody = [],
    loading, addDriver, updateDriver, deleteDriver,
  } = useData();

  const currentMonth = useMemo(getCurrentMonth, []);

  // Full report: job stats (ops/acres/revenue) + salary status + equipment,
  // all in one place so the drivers list can show everything at a glance.
  const report = useMemo(() => {
    const base = buildDriverReport(drivers, jobs, settings.fuelPrice, payments);
    return base.map((drv) => {
      const status = drv.status === DRIVER_STATUS.INACTIVE ? DRIVER_STATUS.INACTIVE : DRIVER_STATUS.ACTIVE;

      const monthEntries = getMonthEntries(salaryEntries, drv.id, currentMonth);
      const baseEntriesThisMonth = monthEntries.filter((e) => e.type === SALARY_ENTRY_TYPES.BASE);
      const unpaidThisMonth = (drv.salary > 0)
        && (baseEntriesThisMonth.length === 0 || baseEntriesThisMonth.some((e) => !e.paid));

      // آخر قيد "صرف راتب أساسي" مدفوع الشهر ده — لو موجود، بيسمح بزرار
      // "إلغاء صرف الراتب" اللي بيمسحه بدل ما نضطر ندخل تفاصيل السائق.
      const paidBaseEntriesThisMonth = baseEntriesThisMonth.filter((e) => e.paid);
      const lastPaidBaseEntry = paidBaseEntriesThisMonth.length
        ? paidBaseEntriesThisMonth.reduce((a, b) => ((a.date || "") >= (b.date || "") ? a : b))
        : null;

      const assignedEquipment = equipment
        .filter((eq) => eq.driverId === drv.id)
        .map((eq) => eq.name);

      return { ...drv, status, unpaidThisMonth, lastPaidBaseEntry, assignedEquipment };
    });
  }, [drivers, jobs, settings.fuelPrice, payments, salaryEntries, equipment, currentMonth]);

  const getById = (id) => drivers.find((d) => d.id === id);

  // (audit finding B2) Counts of every record tied to a driver — used to
  // BLOCK deletion outright when any exist, not just warn about a partial
  // list before still allowing it. Previously this omitted `equipment`
  // (a driver currently assigned to a piece of equipment) and `custody`
  // (custody expense history) entirely, so deleting a driver assigned to
  // equipment or with custody records silently orphaned those references
  // with zero warning even in the "careful" path. Deactivating (status:
  // "inactive", already supported by DriverForm) is always available as the
  // non-destructive alternative.
  const getDriverDependencyCounts = useCallback((driverId) => ({
    jobs:          jobs.filter((j) => j.driverId === driverId).length,
    salaryEntries: salaryEntries.filter((e) => e.driverId === driverId).length,
    attendance:    attendance.filter((a) => a.driverId === driverId).length,
    equipment:     equipment.filter((eq) => eq.driverId === driverId).length,
    custody:       custody.filter((c) => c.driverId === driverId).length,
  }), [jobs, salaryEntries, attendance, equipment, custody]);

  return {
    drivers,
    report,
    loading,
    getById,
    getDriverDependencyCounts,
    addDriver,
    updateDriver,
    deleteDriver,
  };
};
